package com.mycompany.app;

public class App {
    public static String getHello() {
        return "Hello";
    }
}

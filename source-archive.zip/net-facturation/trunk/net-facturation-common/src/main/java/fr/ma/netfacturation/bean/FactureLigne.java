package fr.ma.netfacturation.bean;

import java.io.Serializable;

public class FactureLigne implements Serializable {

	private static final long	serialVersionUID	= 8658075801793894170L;
	
	private String reference;
	private String description;
	private Float prixUnitaireHT;
	private Float quantite;
	private String unite;
	private Float montantHT;
	private Float tva;
	
	public String getReference() {
		return reference;
	}
	public void setReference(String reference) {
		this.reference = reference;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Float getPrixUnitaireHT() {
		return prixUnitaireHT;
	}
	public void setPrixUnitaireHT(Float prixUnitaireHT) {
		this.prixUnitaireHT = prixUnitaireHT;
	}
	public Float getQuantite() {
		return quantite;
	}
	public void setQuantite(Float quantite) {
		this.quantite = quantite;
	}
	public Float getMontantHT() {
		return montantHT;
	}
	public void setMontantHT(Float montantHT) {
		this.montantHT = montantHT;
	}
	public String getUnite() {
		return unite;
	}
	public void setUnite(String unite) {
		this.unite = unite;
	}
	public Float getTva() {
		return tva;
	}
	public void setTva(Float tva) {
		this.tva = tva;
	}
	@Override
	public String toString() {
		return super.toString();
	}
	
}

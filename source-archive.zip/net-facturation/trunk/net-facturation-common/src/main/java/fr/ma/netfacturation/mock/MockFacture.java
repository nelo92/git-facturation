package fr.ma.netfacturation.mock;

import fr.ma.netfacturation.bean.Facture;
import fr.ma.netfacturation.bean.FactureLigne;
import fr.ma.netfacturation.utils.DateUtils;

public class MockFacture extends Facture {

	private static final long	serialVersionUID	= -5268458473230777252L;

	public MockFacture() {		
		setVendeur(new MockVendeur());		
		setAcheteur(new MockAcheteur());
		setNumero("FAC-2012-09");
		setUniteMonetaire("euro");
		setDateEmission(DateUtils.now());
		setMessageEntete("message entete");
		setMessageBasDePage("message bas de page");

		FactureLigne factureLigne = new FactureLigne();
		factureLigne.setReference("PRES1");
		factureLigne.setDescription("PRES DESCRIPTION");
		factureLigne.setPrixUnitaireHT(new Float(1000));
		factureLigne.setQuantite(new Float(20));		
		factureLigne.setTva(new Float(19.6));
		factureLigne.setMontantHT(new Float(5000));
		
		// Totaux - doivent être calculé. 
		setTotalHT(new Float(10000));
		setTotalTVA(new Float(2500));
		setTotalTTC(new Float(12000));	
	}
	
}

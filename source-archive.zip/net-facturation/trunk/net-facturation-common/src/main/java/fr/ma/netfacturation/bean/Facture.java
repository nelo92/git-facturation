package fr.ma.netfacturation.bean;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

import fr.ma.netfacturation.utils.ToStringStyle;

public class Facture implements Serializable {
	
	private static final long	serialVersionUID	= -7072304184660950548L;
	
	private String				numero;
	private Societe				vendeur;
	private Societe				acheteur;
	private String				uniteMonetaire;
	private Date				dateEmission;
	private String				messageEntete;
	private String				messageBasDePage;
	private List<FactureLigne>	FactureLigne;
	private Float				totalTVA;
	private Float				totalHT;
	private Float				totalTTC;
	
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}
	public String getUniteMonetaire() {
		return uniteMonetaire;
	}
	public void setUniteMonetaire(String uniteMonetaire) {
		this.uniteMonetaire = uniteMonetaire;
	}
	public Date getDateEmission() {
		return dateEmission;
	}
	public void setDateEmission(Date dateEmission) {
		this.dateEmission = dateEmission;
	}
	public String getMessageEntete() {
		return messageEntete;
	}
	public void setMessageEntete(String messageEntete) {
		this.messageEntete = messageEntete;
	}
	public String getMessageBasDePage() {
		return messageBasDePage;
	}
	public void setMessageBasDePage(String messageBasDePage) {
		this.messageBasDePage = messageBasDePage;
	}
	public List<FactureLigne> getFactureLigne() {
		return FactureLigne;
	}
	public void setFactureLigne(List<FactureLigne> factureLigne) {
		FactureLigne = factureLigne;
	}
	public Float getTotalTVA() {
		return totalTVA;
	}
	public void setTotalTVA(Float totalTVA) {
		this.totalTVA = totalTVA;
	}
	public Float getTotalHT() {
		return totalHT;
	}
	public void setTotalHT(Float totalHT) {
		this.totalHT = totalHT;
	}
	public Float getTotalTTC() {
		return totalTTC;
	}
	public void setTotalTTC(Float totalTTC) {
		this.totalTTC = totalTTC;
	}	
	public Societe getVendeur() {
		return vendeur;
	}
	public void setVendeur(Societe vendeur) {
		this.vendeur = vendeur;
	}
	public Societe getAcheteur() {
		return acheteur;
	}
	public void setAcheteur(Societe acheteur) {
		this.acheteur = acheteur;
	}
	@Override
	public String toString() {
		ToStringBuilder sb = new ToStringBuilder(this, ToStringStyle.DEFAULT_STYLE);
		sb.append("numero", numero);
		sb.append("vendeur", vendeur);
		sb.append("acheteur", acheteur);
		sb.append("uniteMonetaire", uniteMonetaire);	
		sb.append("dateEmission", dateEmission);
		sb.append("messageEntete", messageEntete);
		sb.append("messageBasDePage", messageBasDePage);
		sb.append("totalHT", totalHT);
		sb.append("totalTVA", totalTVA);
		sb.append("totalTTC", totalTTC);
		sb.append("FactureLigne", FactureLigne);		
		return sb.toString();
	}
	
}
package fr.ma.netfacturation.pdf;

import java.awt.Color;
import java.io.FileOutputStream;

import com.lowagie.text.Cell;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import fr.ma.netfacturation.bean.Adresse;
import fr.ma.netfacturation.bean.Contact;
import fr.ma.netfacturation.bean.Facture;
import fr.ma.netfacturation.bean.Societe;
import fr.ma.netfacturation.mock.MockFacture;

public class CreateFacturePdf {

	
	public static final Font FONT = new Font(Font.HELVETICA, 8, Font.NORMAL, new Color(0, 0, 0)); 
	
	
//	Voir :circle
//	PdfContentByte
	
	public CreateFacturePdf(Facture facture) throws Exception {		
	}
	
	public static void testCreateFacturePdf(Facture facture)  throws Exception {
		
		Document document = new Document(PageSize.A4, 50, 50, 50, 50);
		PdfWriter.getInstance(document, new FileOutputStream("FAC-TEST.pdf"));
		document.open();

		// Vendeur
		printSociete(document, facture.getVendeur());
		
		//
		printTitre(document);
		
		// Acheteur
		printSociete(document, facture.getAcheteur());
	
		// entete 
		printEntete(document, facture.getMessageEntete());

		// Ligne de facture
		printLigneFacturation(document);
		
		// bas de page
		printBasDePage(document, facture.getMessageBasDePage());
		
		document.close();	
	}
	
	public static void printContact(Document document, Contact contact) throws Exception {
		document.add(new Paragraph(new Phrase(contact.getNom() + " "+ contact.getPrenom(), FONT)));
		document.add(new Paragraph(new Phrase(contact.getMail(), FONT)));
		document.add(new Paragraph(new Phrase(contact.getTelephone(), FONT)));
	}
	
	public static void printAdresse(Document document, Adresse adresse) throws Exception {
		document.add(new Paragraph( new Phrase(adresse.getAdresse1(), FONT)));
		document.add(new Paragraph(new Phrase(adresse.getAdresse2(), FONT)));
		document.add(new Paragraph(new Phrase(adresse.getCodePostal() + " " + adresse.getVille(), FONT)));
		document.add(new Paragraph(new Phrase(adresse.getPays(), FONT)));
	}
	
	public static void printSociete(Document document, Societe societe) throws Exception  {
		document.add(new Paragraph(new Phrase(societe.getNom(), FONT)));
		printAdresse(document, societe.getAdresse());
		printContact(document, societe.getContact());
		document.add(new Paragraph(new Phrase(societe.getNumeroIdentification(), FONT)));
	}

	
	public static void printEntete(Document document, String message) throws Exception {
		document.add(new Phrase(message, FONT));
	}
	
	public static void printBasDePage(Document document, String message) throws Exception {
		document.add(new Phrase(message, FONT));
	}
	
	public static void printLigneFacturation(Document document) throws Exception {
	
		int NB_COLONNE = 6;
		String ENTETE_REFERENCE = "REFERENCE";
		String ENTETE_DESIGNATION = "DESIGNATION";
		String ENTETE_QUANTITE = "QUANTITE";
		String ENTETE_PRIX_UNITAIRE_HT = "P.U. HT";
		String ENTETE_MONTANT_HT = "MONTANT HT";
		String ENTETE_TVA = "TVA";
		
		Table table = new Table(NB_COLONNE);
		
		System.out.println("width : " + document.getPageSize().getWidth());
		
		// entete 
		
		Cell cell = new Cell(new Phrase(ENTETE_REFERENCE, FONT));
		cell.setHeader(true);
//		cell.setBackgroundColor(Color.darkGray.brighter().brighter().brighter());
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_TOP);
		table.addCell(cell);
		
		cell = new Cell(new Phrase(ENTETE_DESIGNATION, FONT));
		cell.setHeader(true);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		table.addCell(cell);
		
		cell = new Cell(new Phrase(ENTETE_QUANTITE, FONT));
		cell.setHeader(true);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		table.addCell(cell);
		
		cell = new Cell(new Phrase(ENTETE_PRIX_UNITAIRE_HT, FONT));
		cell.setHeader(true);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);		
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		table.addCell(cell);
		
		cell = new Cell(new Phrase(ENTETE_MONTANT_HT, FONT));
		cell.setHeader(true);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		table.addCell(cell);
		
		cell = new Cell(new Phrase(ENTETE_TVA, FONT));
		cell.setHeader(true);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		table.addCell(cell);
		
		// contenu
		
		
		document.add(table);
	}
	
	public static void  testTableRound(Document document) throws Exception {
		PdfPTable table = new PdfPTable(1);		
		PdfPCell cell = new PdfPCell();
		cell.addElement(new Phrase("test", FONT));
		cell.setCellEvent(new RoundRectangle());	
		cell.setBorder(PdfPCell.NO_BORDER);		
		table.addCell(cell);		
		document.add(table);
	}
	public static void  printTitre(Document document) throws Exception {
		PdfPTable table = new PdfPTable(1);
		table.setWidthPercentage(30f);
		PdfPCell cell = new PdfPCell();
		
		PdfPTable table2 = new PdfPTable(1);
		
		PdfPCell cell1 = new PdfPCell();
		cell1.addElement(new Phrase("FACTURE EN EUR", FONT));
		cell1.setBorder(PdfPCell.NO_BORDER);
		table2.addCell(cell1);
		
		PdfPCell cell2 = new PdfPCell();
		cell2.addElement(new Phrase("N° FACT-2012-09", FONT));
		cell2.setBorder(PdfPCell.NO_BORDER);
		table2.addCell(cell2);
		
		PdfPCell cell3 = new PdfPCell();
		cell3.addElement(new Phrase("Emise le 10/12/2012", FONT));
		cell3.setBorder(PdfPCell.NO_BORDER);
		table2.addCell(cell3);
		
		cell.addElement(table2);
		cell.setCellEvent(new RoundRectangle());	
		cell.setBorder(PdfPCell.NO_BORDER);		
		table.addCell(cell);		
		document.add(table);
	}
	
	public static void main(String arg[]) throws Exception {	
		testCreateFacturePdf(new MockFacture());
	}
	
}

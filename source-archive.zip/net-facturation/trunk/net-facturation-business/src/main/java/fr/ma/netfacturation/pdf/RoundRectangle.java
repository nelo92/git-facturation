package fr.ma.netfacturation.pdf;

import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPCellEvent;
import com.lowagie.text.pdf.PdfPTable;

public class RoundRectangle implements PdfPCellEvent {

	public void cellLayout(PdfPCell cell, Rectangle rect, PdfContentByte[] canvas) {			
		PdfContentByte cb = canvas[PdfPTable.LINECANVAS];  
		
		//cb.setColorStroke(new GrayColor(0.8f));  
//		cb.roundRectangle(rect.getLeft() + 4, rect.getBottom(), rect.getWidth() - 8,  rect.getHeight() - 4, 25);
		
		cb.roundRectangle(rect.getLeft() + 1.5f, rect.getBottom() + 1.5f,  rect.getWidth() - 4,  rect.getHeight() - 4, 4);
		cb.setLineWidth(0.5f);

		cb.stroke();  			
	}

}
